# Change Log

All notable changes to this project will be documented in this file.

## v1.6.0

Adding Multi-bar support

## v1.6.1

Signed, as required by Grafana 7.x.x. No other changes

## v1.7.0

Adding label and group reformatting rules, plus optional reformat-in-place for date/time field.
